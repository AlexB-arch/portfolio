/**
 * Calculator
 * do some maths
 */
public class Calculator 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello Calculator! AMA." );
    }
    
    // Addition
    public int add (int x, int y)
    {
	return x+y;
    }
    
    // Substraction
    public int subtract (int x, int y)
    {
        return x-y;
    }

    // Multiplication
    public int multiply (int x, int y)
    {
        return x*y;
    }

    // Division
    public int divide (int x, int y)
    {
        return x/y;
    }

    // Squared
    public int squared (int x)
    {
        return x*x;
    }
}
