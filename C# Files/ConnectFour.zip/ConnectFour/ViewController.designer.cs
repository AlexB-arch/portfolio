// WARNING
//
// This file has been generated automatically by Visual Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;
using System.CodeDom.Compiler;

namespace ConnectFour
{
	[Register ("ViewController")]
	partial class ViewController
	{
		[Outlet]
		AppKit.NSTextField OutcomeField { get; set; }

		[Outlet]
		AppKit.NSTextField PlayerTurnField { get; set; }

		[Outlet]
		AppKit.NSTextField WinrateLabel { get; set; }

		[Outlet]
		AppKit.NSButton x0y0 { get; set; }

		[Outlet]
		AppKit.NSButton x0y1 { get; set; }

		[Outlet]
		AppKit.NSButton x0y2 { get; set; }

		[Outlet]
		AppKit.NSButton x0y3 { get; set; }

		[Outlet]
		AppKit.NSButton x0y4 { get; set; }

		[Outlet]
		AppKit.NSButton x0y5 { get; set; }

		[Outlet]
		AppKit.NSButton x0y6 { get; set; }

		[Outlet]
		AppKit.NSButton x1y0 { get; set; }

		[Outlet]
		AppKit.NSButton x1y1 { get; set; }

		[Outlet]
		AppKit.NSButton x1y2 { get; set; }

		[Outlet]
		AppKit.NSButton x1y3 { get; set; }

		[Outlet]
		AppKit.NSButton x1y4 { get; set; }

		[Outlet]
		AppKit.NSButton x1y5 { get; set; }

		[Outlet]
		AppKit.NSButton x1y6 { get; set; }

		[Outlet]
		AppKit.NSButton x2y0 { get; set; }

		[Outlet]
		AppKit.NSButton x2y1 { get; set; }

		[Outlet]
		AppKit.NSButton x2y2 { get; set; }

		[Outlet]
		AppKit.NSButton x2y3 { get; set; }

		[Outlet]
		AppKit.NSButton x2y4 { get; set; }

		[Outlet]
		AppKit.NSButton x2y5 { get; set; }

		[Outlet]
		AppKit.NSButton x2y6 { get; set; }

		[Outlet]
		AppKit.NSButton x3y0 { get; set; }

		[Outlet]
		AppKit.NSButton x3y1 { get; set; }

		[Outlet]
		AppKit.NSButton x3y2 { get; set; }

		[Outlet]
		AppKit.NSButton x3y3 { get; set; }

		[Outlet]
		AppKit.NSButton x3y4 { get; set; }

		[Outlet]
		AppKit.NSButton x3y5 { get; set; }

		[Outlet]
		AppKit.NSButton x3y6 { get; set; }

		[Outlet]
		AppKit.NSButton x4y0 { get; set; }

		[Outlet]
		AppKit.NSButton x4y1 { get; set; }

		[Outlet]
		AppKit.NSButton x4y2 { get; set; }

		[Outlet]
		AppKit.NSButton x4y3 { get; set; }

		[Outlet]
		AppKit.NSButton x4y4 { get; set; }

		[Outlet]
		AppKit.NSButton x4y5 { get; set; }

		[Outlet]
		AppKit.NSButton x4y6 { get; set; }

		[Outlet]
		AppKit.NSButton x5y0 { get; set; }

		[Outlet]
		AppKit.NSButton x5y1 { get; set; }

		[Outlet]
		AppKit.NSButton x5y2 { get; set; }

		[Outlet]
		AppKit.NSButton x5y3 { get; set; }

		[Outlet]
		AppKit.NSButton x5y4 { get; set; }

		[Outlet]
		AppKit.NSButton x5y5 { get; set; }

		[Outlet]
		AppKit.NSButton x5y6 { get; set; }

		[Action ("PlayAgainButton:")]
		partial void PlayAgainButton (Foundation.NSObject sender);

		[Action ("ResetButton:")]
		partial void ResetButton (Foundation.NSObject sender);

		[Action ("X0Y5:")]
		partial void X0Y5 (Foundation.NSObject sender);

		[Action ("X5Y0:")]
		partial void X5Y0 (Foundation.NSObject sender);

		[Action ("X5Y1:")]
		partial void X5Y1 (Foundation.NSObject sender);

		[Action ("X5Y2:")]
		partial void X5Y2 (Foundation.NSObject sender);

		[Action ("X5Y3:")]
		partial void X5Y3 (Foundation.NSObject sender);

		[Action ("X5Y4:")]
		partial void X5Y4 (Foundation.NSObject sender);

		[Action ("X5Y5:")]
		partial void X5Y5 (Foundation.NSObject sender);

		[Action ("X5Y6:")]
		partial void X5Y6 (Foundation.NSObject sender);
		
		void ReleaseDesignerOutlets ()
		{
			if (x0y0 != null) {
				x0y0.Dispose ();
				x0y0 = null;
			}

			if (x1y0 != null) {
				x1y0.Dispose ();
				x1y0 = null;
			}

			if (x2y0 != null) {
				x2y0.Dispose ();
				x2y0 = null;
			}

			if (x3y0 != null) {
				x3y0.Dispose ();
				x3y0 = null;
			}

			if (x4y0 != null) {
				x4y0.Dispose ();
				x4y0 = null;
			}

			if (x5y0 != null) {
				x5y0.Dispose ();
				x5y0 = null;
			}

			if (x4y1 != null) {
				x4y1.Dispose ();
				x4y1 = null;
			}

			if (x3y1 != null) {
				x3y1.Dispose ();
				x3y1 = null;
			}

			if (x2y1 != null) {
				x2y1.Dispose ();
				x2y1 = null;
			}

			if (x1y1 != null) {
				x1y1.Dispose ();
				x1y1 = null;
			}

			if (x0y1 != null) {
				x0y1.Dispose ();
				x0y1 = null;
			}

			if (x0y2 != null) {
				x0y2.Dispose ();
				x0y2 = null;
			}

			if (x0y3 != null) {
				x0y3.Dispose ();
				x0y3 = null;
			}

			if (x0y4 != null) {
				x0y4.Dispose ();
				x0y4 = null;
			}

			if (x0y5 != null) {
				x0y5.Dispose ();
				x0y5 = null;
			}

			if (x0y6 != null) {
				x0y6.Dispose ();
				x0y6 = null;
			}

			if (x1y2 != null) {
				x1y2.Dispose ();
				x1y2 = null;
			}

			if (x1y3 != null) {
				x1y3.Dispose ();
				x1y3 = null;
			}

			if (x1y4 != null) {
				x1y4.Dispose ();
				x1y4 = null;
			}

			if (x1y5 != null) {
				x1y5.Dispose ();
				x1y5 = null;
			}

			if (x1y6 != null) {
				x1y6.Dispose ();
				x1y6 = null;
			}

			if (x2y2 != null) {
				x2y2.Dispose ();
				x2y2 = null;
			}

			if (x2y3 != null) {
				x2y3.Dispose ();
				x2y3 = null;
			}

			if (x2y4 != null) {
				x2y4.Dispose ();
				x2y4 = null;
			}

			if (x2y5 != null) {
				x2y5.Dispose ();
				x2y5 = null;
			}

			if (x2y6 != null) {
				x2y6.Dispose ();
				x2y6 = null;
			}

			if (x3y2 != null) {
				x3y2.Dispose ();
				x3y2 = null;
			}

			if (x3y3 != null) {
				x3y3.Dispose ();
				x3y3 = null;
			}

			if (x3y4 != null) {
				x3y4.Dispose ();
				x3y4 = null;
			}

			if (x3y5 != null) {
				x3y5.Dispose ();
				x3y5 = null;
			}

			if (x3y6 != null) {
				x3y6.Dispose ();
				x3y6 = null;
			}

			if (x4y2 != null) {
				x4y2.Dispose ();
				x4y2 = null;
			}

			if (x4y3 != null) {
				x4y3.Dispose ();
				x4y3 = null;
			}

			if (x4y4 != null) {
				x4y4.Dispose ();
				x4y4 = null;
			}

			if (x4y5 != null) {
				x4y5.Dispose ();
				x4y5 = null;
			}

			if (x4y6 != null) {
				x4y6.Dispose ();
				x4y6 = null;
			}

			if (x5y1 != null) {
				x5y1.Dispose ();
				x5y1 = null;
			}

			if (x5y2 != null) {
				x5y2.Dispose ();
				x5y2 = null;
			}

			if (x5y3 != null) {
				x5y3.Dispose ();
				x5y3 = null;
			}

			if (x5y4 != null) {
				x5y4.Dispose ();
				x5y4 = null;
			}

			if (x5y5 != null) {
				x5y5.Dispose ();
				x5y5 = null;
			}

			if (x5y6 != null) {
				x5y6.Dispose ();
				x5y6 = null;
			}

			if (PlayerTurnField != null) {
				PlayerTurnField.Dispose ();
				PlayerTurnField = null;
			}

			if (OutcomeField != null) {
				OutcomeField.Dispose ();
				OutcomeField = null;
			}

			if (WinrateLabel != null) {
				WinrateLabel.Dispose ();
				WinrateLabel = null;
			}
		}
	}
}
